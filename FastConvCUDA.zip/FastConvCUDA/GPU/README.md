exp_conv_gpu
============

GPU implementation of the exponential convolution quadrature function.
