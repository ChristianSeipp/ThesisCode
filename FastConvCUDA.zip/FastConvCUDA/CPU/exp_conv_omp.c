// This was an attempt at an OpenMP parallel implementation. I do not recall getting a good result with this code.

// Eric Wolf
// October 21, 2016
// Email: eriwolf@gmail.com

#include <math.h>
#include <string.h>
#include <time.h>
#include <stdio.h>
#include <omp.h>


int main(void){


/* Physical constants */
float c = 1; /* Wave speed */


/* Numerical parameters */

/* Domain set up */
float L = 1; /* Total length of the domain */
int Nx = (int)pow(2,22); /* Total number of grid points; so 1D arrays will run [0:Nx-1] */
printf("Number of grid points: %i\n", Nx);

float dx = L/(Nx-1);


int Nt = 10000; /* Number of time steps */
printf("Number of time steps: %i\n",Nt);

/* Implicit solver parameters
We use the 2nd order centered ("purely dispersive") version of the solver.
 */
float alpha = 2/(c*dt);
float nu = dx*alpha;
float ex = exp(-nu);
float eL = exp(-alpha*L);

/* Quadrature weights */
float P = 1 - (1-ex)/nu;
float Q = -ex+(1-ex)/nu;
float R = (1-ex)/(nu*nu)-(1+ex)/(2*nu);


/* Parallelization parameters - division into subdomains 
Nx is a power of 2, so subDomainElements should be power of 2 as well to evenly divide it.

The choice of subDomainElements seems to significantly affect the performance. Some experimentation with different values showed subDomainElements = 16
to give the best performance; increasing from 16 seems to slow down the code up to a point, after which further increase in subDomainElements speeds up the code.
What's the best choice for subDomainElements, and why?
*/
int subDomainElements =  16; //16*(int)pow(2,9);
int numSubDomains = Nx/subDomainElements;
printf("Number of subdomains: %i\n", numSubDomains);




/* Solution array set up */

/* Main solution arrays */
float integrand[Nx];
float I[Nx];


float JR[Nx],JL[Nx],IR[Nx],IL[Nx];


/* Some indices for utility */
int n;
int j;
int i;
int flat;






/*************************************************** Time loop **************************************************************************/
clock_t start = clock(), diff;
for(int n = 1; n <= Nt; n++){
#pragma omp parallel
	{
#pragma omp for		
	for(int i=0; i<numSubDomains; i++){
		for(int j=0; j<subDomainElements-1; j++){
			flat = (i+1)*subDomainElements - j;
			JR[flat]=P*integrand[flat+1]+Q*integrand[flat+2]+R*(integrand[flat+2]-2*integrand[flat+1]+integrand[flat]);
			JR[flat] = ex*JR[flat+1]+JR[flat];
		}
	}	
}
}
diff = clock() - start;
int sec = diff/ CLOCKS_PER_SEC;
printf("Time taken: %d seconds\n", sec);

return 0;
}
