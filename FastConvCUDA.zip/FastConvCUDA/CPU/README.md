exp_conv_cpu
============

CPU implementation of the exponential convolution quadrature function.
